# MusicSimilarity

Masters Thesis 

Music Similarity Analysis Using the Big Data Framework Spark
